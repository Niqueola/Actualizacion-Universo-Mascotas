<script>
$("#ship_co").change( function() {
	UpdateShipCo();
})
</script>