
  $(document).ready(function() {


  	      console.log("prueba de vendor");
  });

